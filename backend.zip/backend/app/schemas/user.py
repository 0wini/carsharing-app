from typing import NewType, Annotated
from pydantic import BaseModel, EmailStr, constr
from datetime import date


PasswordStr = NewType('PasswordStr', str)

class UserRegister(BaseModel):
    email: EmailStr
    password: PasswordStr  # typ len pre IDE, validáciu vyriešime v Pydantic validators
    first_name: str
    last_name: str
    birth_date: date
    phone: str

    # vlastná validácia (Pydantic)
    @classmethod
    def validate(cls, values):
        password = values.get("password")
        if password and len(password) < 6:
            raise ValueError("Password must be at least 6 characters")
        return values

class UserLogin(BaseModel):
    email: EmailStr
    password: str

from pydantic import BaseModel, constr

class UserUpdatePhone(BaseModel):
    phone: Annotated[str, constr(min_length=7, max_length=20)]
