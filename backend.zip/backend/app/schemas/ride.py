from pydantic import BaseModel, constr  
from datetime import datetime
from typing import Optional
from pydantic.types import Annotated
from pydantic.types import StringConstraints

class RideCreate(BaseModel):
    origin: str
    destination: str
    departure_time: datetime
    seats_available: int
    price: Optional[float] = None
    driver_email: Optional[str] = None

    # Nové polia:
    comment: Optional[Annotated[str, StringConstraints(max_length=250)]] = None
    is_recurring: Optional[bool] = False
    periodic: Optional[str] = None

    model_config = {"from_attributes": True}


class RideWithDriver(BaseModel):
    id: int
    origin: str
    destination: str
    departure_time: datetime
    seats_available: int
    price: float
    driver_email: str
    driver_first_name: str
    driver_last_name: str

    # Nové polia:
    comment: Optional[str] = None
    is_recurring: Optional[bool] = None
    periodic: Optional[str] = None

    model_config = {"from_attributes": True}
