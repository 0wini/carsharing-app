import json
from pathlib import Path
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.schemas.user import UserRegister, UserLogin, UserUpdatePhone
from app.services.auth import (
    hash_password,
    verify_password,
    create_access_token,
    get_current_user,
)
from app.database.models.user import User
from app.database.database import get_db
from datetime import date


router = APIRouter()


def load_allowed_domains():
    path = Path(__file__).parent.parent / "config" / "allowed_domains.json"
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get("domains", [])


@router.post("/register")
async def register_user(user: UserRegister, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.email == user.email))
    existing_user = result.scalar_one_or_none()

    if existing_user:
        raise HTTPException(status_code=400, detail="E-mail sa už používa")

    # Validácia domény
    allowed_domains = load_allowed_domains()
    email_domain = user.email.split('@')[-1]

    if email_domain not in allowed_domains:
        raise HTTPException(status_code=400, detail="Doména mailu nepatrí k povoleným doménám")

    new_user = User(
        email=user.email,
        hashed_password=hash_password(user.password),
        first_name=user.first_name,
        last_name=user.last_name,
        birth_date=user.birth_date,
        phone=user.phone
    )

    db.add(new_user)
    await db.commit()

    return {"message": "Registrácia prebehla úspešne"}


@router.post("/login")
async def login(user: UserLogin, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.email == user.email))
    db_user = result.scalar_one_or_none()

    if not db_user or not verify_password(user.password, db_user.hashed_password):
        raise HTTPException(status_code=401, detail="Nesprávne meno alebo heslo")

    access_token = create_access_token(data={"sub": db_user.email})
    return {
    "access_token": access_token,
    "token_type": "bearer",
    "user_id": db_user.id 
}


@router.get("/protected")
async def protected_route(current_user: str = Depends(get_current_user)):
    return {"message": f"Povolený prístup. Vitaj, {current_user}!"}

from datetime import date

@router.get("/users/me")
async def read_users_me(current_user: User = Depends(get_current_user)):
    birth_date = current_user.birth_date
    age = None
    if birth_date:
        today = date.today()
        age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))

    domain = current_user.email.split("@")[-1]
    school = domain.replace(".sk", "").replace("student.", "").upper()

    return {
        "first_name": current_user.first_name,
        "last_name": current_user.last_name,
        "age": age,
        "phone": current_user.phone,
        "school": school,
        "email": current_user.email
    }

@router.patch("/users/me")
async def update_user_phone(
    update_data: UserUpdatePhone,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    current_user.phone = update_data.phone
    db.add(current_user)
    await db.commit()
    return {"message": "Telefónne číslo bolo aktualizované"}