from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from datetime import datetime
from typing import List, Optional

from app.schemas.ride import RideCreate, RideWithDriver
from app.database.models.ride import Ride
from app.database.models.user import User
from app.services.auth import get_current_user
from app.database.database import get_db
from app.database.models.ride_passenger import RidePassenger

router = APIRouter()

@router.post("/rides")
async def create_ride(
    ride: RideCreate,
    user: str = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    try:
        # DEBUG výpis do konzoly
        print("➡️ Vstupné dáta:")
        print("Používateľ:", user)
        print("Ride objekt:", ride)

        # Vytvorenie objektu Ride
        new_ride = Ride(
            origin=ride.origin,
            destination=ride.destination,
            departure_time=ride.departure_time.replace(tzinfo=None),
            seats_available=ride.seats_available,
            price=ride.price,
            driver_email=user.email,
            comment=ride.comment,
            is_recurring=ride.is_recurring,
            periodic=ride.periodic
        )

        print("🛠️ Objekt pripravený na uloženie:", new_ride)

        db.add(new_ride)
        await db.commit()
        await db.refresh(new_ride)

        # Odpoveď bez neparsovateľných objektov
        return {
            "message": "Vytvorenie jazdy prebehlo úspešne",
            "jazda": {
                "id": new_ride.id,
                "origin": new_ride.origin,
                "destination": new_ride.destination,
                "departure_time": new_ride.departure_time.isoformat(),
                "seats_available": new_ride.seats_available,
                "price": new_ride.price,
                "comment": new_ride.comment,
                "is_recurring": new_ride.is_recurring,
                "periodic": new_ride.periodic
            }
        }

    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Interná chyba servera: {str(e)}")


@router.get("/rides", response_model=List[RideCreate])
async def get_all_rides(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Ride))
    rides = result.scalars().all()
    return rides

@router.get("/rides/search", response_model=List[RideWithDriver])
async def search_rides(
    origin: Optional[str] = None,
    destination: Optional[str] = None,
    date_str: Optional[str] = None,
    seats_required: Optional[int] = None,  # <- pridaj
    db: AsyncSession = Depends(get_db)
):
    from sqlalchemy import cast, Date

    query = select(Ride, User.first_name, User.last_name).join(User, Ride.driver_email == User.email)

    if origin:
        query = query.where(Ride.origin.ilike(origin))
    if destination:
        query = query.where(Ride.destination.ilike(destination))
    if date_str:
        try:
            date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
            query = query.where(cast(Ride.departure_time, Date) == date_obj)
        except ValueError:
            raise HTTPException(status_code=400, detail="Nesprávny formát dátumu. Očakáva sa YYYY-MM-DD.")
    if seats_required is not None:
        query = query.where(Ride.seats_available >= seats_required)  # ← pridaj filter

    result = await db.execute(query)
    rides = result.all()

    response = []
    for ride, first_name, last_name in rides:
        response.append({
            "id": ride.id,
            "origin": ride.origin,
            "destination": ride.destination,
            "departure_time": ride.departure_time,
            "seats_available": ride.seats_available,
            "price": ride.price,
            "driver_email": ride.driver_email,
            "driver_first_name": first_name,
            "driver_last_name": last_name,
        })

    return response

@router.get("/users/{email}")
async def get_user_by_email(email: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.email == email))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Používateľ neexistuje.")
    return {
        "first_name": user.first_name,
        "last_name": user.last_name,
        "email": user.email
    }

@router.post("/rides/{ride_id}/join")
async def join_ride(
    ride_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(select(Ride).where(Ride.id == ride_id))
    ride = result.scalar_one_or_none()
    if not ride:
        raise HTTPException(status_code=404, detail="Jazda neexistuje.")

    result = await db.execute(
        select(RidePassenger).where(
            RidePassenger.user_id == user.id,
            RidePassenger.ride_id == ride_id
        )
    )
    existing = result.scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=400, detail="Už ste prihlásený na túto jazdu.")

    if ride.seats_available <= 0:
        raise HTTPException(status_code=400, detail="Žiadne voľné miesta.")

    new_entry = RidePassenger(user_id=user.id, ride_id=ride_id)
    db.add(new_entry)

    ride.seats_available -= 1
    db.add(ride)

    await db.commit()
    return {"message": "Úspešne ste sa prihlásili na jazdu."}

@router.get("/rides/{ride_id}")
async def get_ride_detail(ride_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Ride).where(Ride.id == ride_id))
    ride = result.scalar_one_or_none()
    if not ride:
        raise HTTPException(status_code=404, detail="Jazda neexistuje")

    result = await db.execute(select(User).where(User.email == ride.driver_email))
    driver = result.scalar_one()

    result = await db.execute(
        select(User.id, User.first_name, User.last_name, User.email)
        .join(RidePassenger, RidePassenger.user_id == User.id)
        .where(RidePassenger.ride_id == ride_id)
    )
    passengers = result.all()

    return {
        "ride": {
            "id": ride.id,
            "origin": ride.origin,
            "destination": ride.destination,
            "departure_time": ride.departure_time,
            "seats_available": ride.seats_available,
            "price": ride.price,
            "comment": ride.comment,
            "is_recurring": ride.is_recurring,
            "periodic": ride.periodic,
        },
        "driver": {
            "first_name": driver.first_name,
            "last_name": driver.last_name,
            "email": driver.email,
            "phone": driver.phone,
        },
        "passengers": [
            {
                "id": p[0],
                "first_name": p[1],
                "last_name": p[2],
                "email": p[3],
            }
            for p in passengers
        ],
    }

@router.get("/rides/my", response_model=List[RideCreate])
async def get_my_rides(
    db: AsyncSession = Depends(get_db),
    user: str = Depends(get_current_user)
):
    result = await db.execute(select(Ride).where(Ride.driver_email == user))
    my_rides = result.scalars().all()
    return my_rides

@router.get("/rides/passenger/{user_id}")
async def get_passenger_rides(user_id: int, db: AsyncSession = Depends(get_db)):
    from sqlalchemy import func

    # Získaj e-mail používateľa podľa jeho ID
    result = await db.execute(select(User.email).where(User.id == user_id))
    user_email = result.scalar_one_or_none()
    if not user_email:
        raise HTTPException(status_code=404, detail="Používateľ neexistuje")

    response = []

    # Jazdy ako pasažier
    result = await db.execute(
        select(Ride)
        .join(RidePassenger, RidePassenger.ride_id == Ride.id)
        .where(RidePassenger.user_id == user_id)
    )
    passenger_rides = result.scalars().all()

    # Jazdy ako vodič
    result = await db.execute(
        select(Ride).where(Ride.driver_email == user_email)
    )
    driver_rides = result.scalars().all()

    # Spoj jazdy a odstráň duplicity
    all_rides = {
    ride.id: ride for ride in passenger_rides + driver_rides
    }.values()


    for ride in all_rides:
        # Získaj vodiča
        result = await db.execute(select(User).where(User.email == ride.driver_email))
        driver = result.scalar_one_or_none()

        # Počet pasažierov
        result = await db.execute(
            select(func.count(RidePassenger.id)).where(RidePassenger.ride_id == ride.id)
        )
        passengers_count = result.scalar()

        # Stav jazdy
        now = datetime.now()
        if ride.departure_time < now:
            status = "Prebehla"
        elif ride.seats_available < 0:
            status = "Zrušená"
        else:
            status = "Rezervovaná"

        response.append({
            "id": ride.id,
            "origin": ride.origin,
            "destination": ride.destination,
            "departure_time": ride.departure_time,
            "price": ride.price,
            "driver_first_name": driver.first_name if driver else "",
            "driver_last_name": driver.last_name if driver else "",
            "passengers_count": passengers_count,
            "status": status
        })

    return response

@router.delete("/rides/{ride_id}/cancel")
async def cancel_ride(
    ride_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(select(Ride).where(Ride.id == ride_id))
    ride = result.scalar_one_or_none()
    if not ride:
        raise HTTPException(status_code=404, detail="Jazda neexistuje.")

    if ride.driver_email != user.email:
        raise HTTPException(status_code=403, detail="Nemáš oprávnenie zrušiť túto jazdu.")

 
    now = datetime.now()
    if ride.departure_time < now or ride.seats_available < 0:
        raise HTTPException(status_code=400, detail="Jazdu už nie je možné zrušiť.")

    ride.seats_available = -1
    await db.commit()

    return {"message": "Jazda bola úspešne zrušená."}



@router.delete("/rides/{ride_id}/leave")
async def leave_ride(
    ride_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(select(Ride).where(Ride.id == ride_id))
    ride = result.scalar_one_or_none()
    if not ride:
        raise HTTPException(status_code=404, detail="Jazda neexistuje.")

    now = datetime.now()
    if ride.departure_time < now or ride.seats_available < 0:
        raise HTTPException(status_code=400, detail="Z tejto jazdy sa už nemôžeš odhlásiť.")

    result = await db.execute(
        select(RidePassenger)
        .where(RidePassenger.ride_id == ride_id, RidePassenger.user_id == user.id)
    )
    entry = result.scalar_one_or_none()
    if not entry:
        raise HTTPException(status_code=404, detail="Nie si prihlásený na túto jazdu.")

    await db.delete(entry)
    ride.seats_available += 1
    db.add(ride)

    await db.commit()
    return {"message": "Rezervácia bola zrušená."}


