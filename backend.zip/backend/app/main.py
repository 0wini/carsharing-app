from fastapi import FastAPI
from fastapi.openapi.utils import get_openapi
from fastapi.middleware.cors import CORSMiddleware
from app.routers import auth, rides, check_email
import logging

logging.basicConfig(level=logging.DEBUG)



app = FastAPI()

# Tu si zmeň IP adresu podľa ipconfig
origins = [
    "http://localhost",
    "http://127.0.0.1:8000",
    "http://172.20.10.4:8000", 
    "https://snack.expo.dev",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Swagger: Pridanie podpory pre Bearer Token
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="Carpooling API",
        version="1.0.0",
        description="API for user registration and authentication",
        routes=app.routes,
    )
    openapi_schema["components"]["securitySchemes"] = {
        "HTTPBearer": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT"
        }
    }
    for path in openapi_schema["paths"].values():
        for method in path.values():
            if "security" not in method:
                method["security"] = [{"HTTPBearer": []}]
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

app.include_router(auth.router)
app.include_router(rides.router)
app.include_router(check_email.router)

@app.get("/")
def root():
    return {"message": "Carsharing API v1"}
