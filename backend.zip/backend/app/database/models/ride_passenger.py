from sqlalchemy import Column, Integer, ForeignKey
from sqlalchemy.orm import relationship
from app.database.database import Base
from app.database.models.ride import Ride
from app.database.models.user import User

class RidePassenger(Base):
    __tablename__ = "ride_passenger"

    id = Column(Integer, primary_key=True, index=True)
    ride_id = Column(Integer, ForeignKey("rides.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    ride = relationship("Ride", back_populates="passengers")
    user = relationship("User", back_populates="joined_rides")
