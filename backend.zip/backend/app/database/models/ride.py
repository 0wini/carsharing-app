from sqlalchemy import Column, String, Integer, Float, DateTime, ForeignKey, Boolean, Text
from app.database.database import Base
from sqlalchemy.orm import relationship

class Ride(Base):
    __tablename__ = "rides"

    id = Column(Integer, primary_key=True, index=True)
    origin = Column(String, nullable=False)
    destination = Column(String, nullable=False)
    departure_time = Column(DateTime, nullable=False)
    seats_available = Column(Integer, nullable=False)
    price = Column(Float, nullable=True)
    driver_email = Column(String, ForeignKey("users.email"), nullable=False)
    passengers = relationship("RidePassenger", back_populates="ride", cascade="all, delete-orphan")
    comment = Column(Text, nullable=True)  # max 250 znakov bude validované cez schému
    is_recurring = Column(Boolean, default=False)
    periodic = Column(String(50), nullable=True)  # napr. "mon,wed,fri"

