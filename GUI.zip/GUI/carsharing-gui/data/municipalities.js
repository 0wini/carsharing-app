const municipalities = [
    "Bratislava",
    "Košice",
    "Prešov",
    "Žilina",
    "Nitra",
    "Trnava",
    "Banská Bystrica",
    "Martin",
    "Poprad",
    "Zvolen"
  ];
  
  export default municipalities;
  