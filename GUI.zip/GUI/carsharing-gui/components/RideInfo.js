import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function RideInfo({ ride }) {
  const {
    origin,
    destination,
    departure_time,
    seats_available,
    price,
    driver_first_name,
    driver_last_name,
  } = ride;

  const driverFullName = `${driver_first_name} ${driver_last_name?.charAt(0)}.`;

  const formattedDate = new Date(departure_time).toLocaleString('sk-SK', {
    day: 'numeric',
    month: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <View style={styles.container}>
      <Text style={styles.line}><Text style={styles.label}>Vodič:</Text> {driverFullName}</Text>
      <Text style={styles.line}><Text style={styles.label}>Trasa:</Text> {origin} ➞ {destination}</Text>
      <Text style={styles.line}><Text style={styles.label}>Odchod:</Text> {formattedDate}</Text>
      <Text style={styles.line}><Text style={styles.label}>Voľné miesta:</Text> {seats_available}</Text>
      <Text style={styles.line}><Text style={styles.label}>Cena:</Text> {price} €</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 20,
    marginVertical: 8,
    padding: 15,
    backgroundColor: '#f2f2f2',
    borderRadius: 8,
    elevation: 2,
  },
  line: {
    fontSize: 15,
    marginBottom: 3,
  },
  label: {
    fontWeight: 'bold',
  },
});
