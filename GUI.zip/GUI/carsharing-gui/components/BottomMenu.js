// BottomMenu.js
import React from 'react';
import { View, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';

const BottomMenu = () => {
  const navigation = useNavigation();
  const route = useRoute();

  const tabs = [
    { name: 'SearchRideScreen', icon: 'search' },
    { name: 'CreateRide', icon: 'plus-circle' },
    { name: 'MyRides', icon: 'car' },
    { name: 'Messages', icon: 'comments' },
    { name: 'Profile', icon: 'user' },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.iconRow}>
        {tabs.map((tab, index) => {
          const isActive = route.name === tab.name;
          return (
            <TouchableOpacity
              key={index}
              onPress={() =>
                navigation.reset({
                  index: 0,
                  routes: [{ name: tab.name }],
                  stale: true,
                })
              }              
              style={styles.iconButton}
            >
              <FontAwesome
                name={tab.icon}
                size={28}
                color={isActive ? '#FF3B30' : '#888'} // červená ak aktívna
              />
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
};

const { height } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    height: 60,
    backgroundColor: '#ffffff',
    borderTopWidth: 1,
    borderColor: '#ccc',
    justifyContent: 'center',
  },
  iconRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'flex-end',
  },
  iconButton: {
    alignItems: 'center',
  },
});

export default BottomMenu;
