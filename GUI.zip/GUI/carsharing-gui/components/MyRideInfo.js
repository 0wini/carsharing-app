import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function MyRideInfo({ ride }) {
  console.log("RIDE:", ride);
  return (
    <View style={styles.card}>
      <Text style={styles.title}>
        {ride.origin} → {ride.destination}
      </Text>
      <Text>Dátum: {new Date(ride.departure_time).toLocaleDateString('sk-SK')}</Text>
      <Text>Čas: {new Date(ride.departure_time).toLocaleTimeString('sk-SK', { hour: '2-digit', minute: '2-digit' })}</Text>
      <Text>Vodič: {ride.driver_first_name ?? 'Neznámy'} {ride.driver_last_name ?? ''}</Text>
      <Text>Cena: {ride.price} €</Text>
      <Text>Počet pasažierov: {ride.passengers_count}</Text>
      <Text>Stav: {String(ride.status ?? 'Neznámy')}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    padding: 15,
    marginBottom: 15,
    backgroundColor: '#f9f9f9',
  },
  title: {
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 5,
  },
});
