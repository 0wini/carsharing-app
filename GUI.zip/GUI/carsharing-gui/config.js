export const allowedDomains = [
    "stuba.sk",
    "student.uniza.sk",
    "student.tuke.sk",
    "student.truni.sk"
  ];
  
  export const BASE_URL = "http://192.168.0.115:8000";