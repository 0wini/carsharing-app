  import React, { useState } from 'react';
  import { NavigationContainer } from '@react-navigation/native';
  import { createNativeStackNavigator } from '@react-navigation/native-stack';
  import Toast from 'react-native-toast-message';

  import LoginScreen from './screens/LoginScreen';
  import RegisterScreen1 from './screens/RegisterScreen1';
  import RegisterScreen2 from './screens/RegisterScreen2';
  import ForgotPasswordScreen1 from './screens/ForgotPasswordScreen1';
  import ForgotPasswordScreen2 from './screens/ForgotPasswordScreen2';

  import SearchRideScreen from './screens/SearchRideScreen';
  import CreateRideScreen from './screens/CreateRideScreen';
  import MyRidesScreen from './screens/MyRidesScreen';
  import MessagesScreen1 from './screens/MessagesScreen1';
  import ProfileScreen from './screens/ProfileScreen';
  import ListOfRidesScreen from './screens/ListOfRidesScreen';
  import RideInfoScreen from './screens/RideInfoScreen';
  import MyRideInfoScreen from './screens/MyRideInfoScreen';
  import PublicProfileScreen from './screens/PublicProfileScreen';



  const Stack = createNativeStackNavigator();

  export default function App() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    return (
      <>
        <NavigationContainer>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            {!isLoggedIn ? (
              <>
                <Stack.Screen name="LoginScreen">
                  {(props) => <LoginScreen {...props} onLogin={() => setIsLoggedIn(true)} />}
                </Stack.Screen>
                <Stack.Screen name="RegisterScreen1" component={RegisterScreen1} />
                <Stack.Screen name="RegisterScreen2" component={RegisterScreen2} />
                <Stack.Screen name="ForgotPasswordScreen1" component={ForgotPasswordScreen1} />
                <Stack.Screen name="ForgotPasswordScreen2" component={ForgotPasswordScreen2} />
              </>
            ) : (
              <>
                <Stack.Screen name="SearchRideScreen" component={SearchRideScreen} />
                <Stack.Screen name="CreateRide" component={CreateRideScreen} />
                <Stack.Screen name="MyRides" component={MyRidesScreen} />
                <Stack.Screen name="Messages" component={MessagesScreen1} />
                <Stack.Screen name="Profile">
                {(props) => <ProfileScreen {...props} setIsLoggedIn={setIsLoggedIn} />}
                </Stack.Screen>
                <Stack.Screen name="ListOfRides" component={ListOfRidesScreen} />
                <Stack.Screen name="RideInfoScreen" component={RideInfoScreen} />
                <Stack.Screen name="MyRideInfoScreen" component={MyRideInfoScreen} />
                <Stack.Screen name="PublicProfileScreen" component={PublicProfileScreen} />

              </>
            )}
          </Stack.Navigator>
        </NavigationContainer>
        <Toast />
      </>
    );
  }
