import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Button, ScrollView, Alert } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { BASE_URL } from '../config';
import { SafeAreaView } from 'react-native-safe-area-context';
import Toast from 'react-native-toast-message';

export default function MyRideInfoScreen({ route, navigation }) {
  const { ride } = route.params;
  const [rideDetails, setRideDetails] = useState(null);
  const [currentUserEmail, setCurrentUserEmail] = useState(null);
  const [currentUserId, setCurrentUserId] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      const email = await AsyncStorage.getItem('user_email');
      const id = await AsyncStorage.getItem('user_id');
      setCurrentUserEmail(email);
      setCurrentUserId(Number(id));
      fetchRideDetail();
    };
    fetchData();
  }, []);

  const fetchRideDetail = async () => {
    try {
      const res = await fetch(`${BASE_URL}/rides/${ride.id}`);
      const data = await res.json();
      setRideDetails(data);
    } catch (error) {
      console.error("Chyba pri načítaní detailu jazdy", error);
    }
  };

  const cancelRide = async () => {
    try {
      const token = await SecureStore.getItemAsync('token');
      const res = await fetch(`${BASE_URL}/rides/${ride.id}/cancel`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();
      if (res.ok) {
        Toast.show({ type: 'success', text1: data.message });
        navigation.goBack();
      } else {
        Toast.show({ type: 'error', text1: data.detail });
      }
    } catch (error) {
      Toast.show({ type: 'error', text1: "Chyba pri rušení jazdy" });
    }
  };

  const cancelReservation = async () => {
    try {
      const token = await SecureStore.getItemAsync('token');
      const res = await fetch(`${BASE_URL}/rides/${ride.id}/cancel-reservation`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await res.json();
      if (res.ok) {
        Toast.show({ type: 'success', text1: data.message });
        navigation.goBack();
      } else {
        Toast.show({ type: 'error', text1: data.detail });
      }
    } catch (error) {
      Toast.show({ type: 'error', text1: "Chyba pri rušení rezervácie" });
    }
  };

  if (!rideDetails) return <Text>Načítava sa...</Text>;

  const { ride: r, driver, passengers } = rideDetails;
  const isDriver = driver.email === currentUserEmail;
  const isPast = new Date(r.departure_time) < new Date();
  const isCancelled = r.seats_available < 0;
  const isLocked = isPast || isCancelled;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Moja jazda</Text>

        <Text style={styles.label}>Trasa:</Text>
        <Text style={styles.value}>{r.origin} ➞ {r.destination}</Text>

        <Text style={styles.label}>Odchod:</Text>
        <Text style={styles.value}>{new Date(r.departure_time).toLocaleString()}</Text>

        <Text style={styles.label}>Cena:</Text>
        <Text style={styles.value}>{r.price} €</Text>

        <Text style={styles.label}>Voľné miesta:</Text>
        <Text style={styles.value}>
          {isLocked ? 0 : r.seats_available}
        </Text>

        <Text style={styles.label}>Poznámka:</Text>
        <Text style={styles.value}>{r.comment || "Žiadna"}</Text>

        {isDriver ? (
          <>
            <Text style={styles.label}>Pasažieri:</Text>
            {passengers.length > 0 ? passengers.map((p, idx) => (
              <Text key={idx} style={styles.value}>
                {p.first_name} {p.last_name?.charAt(0)}. – {p.email} – {p.phone}
              </Text>
            )) : <Text style={styles.value}>Žiadni</Text>}
          </>
        ) : (
          <>
            <Text style={styles.label}>Telefón na vodiča:</Text>
            <Text style={styles.value}>{driver.phone}</Text>
          </>
        )}

        <View style={styles.buttonContainer}>
          {isDriver ? (
            <Button
              title="Zrušiť jazdu"
              onPress={cancelRide}
              color="red"
              disabled={isLocked}
            />
          ) : (
            <Button
              title="Zrušiť rezerváciu"
              onPress={cancelReservation}
              color="orange"
              disabled={isLocked}
            />
          )}
        </View>

        <View style={styles.buttonContainer}>
          <Button title="Späť" onPress={() => navigation.goBack()} />
        </View>
        <Toast />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  label: { fontSize: 16, fontWeight: 'bold', marginTop: 10 },
  value: { fontSize: 16, marginBottom: 5 },
  buttonContainer: { marginTop: 20 },
});
