import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, Button, ActivityIndicator,
  TextInput, TouchableOpacity, Dimensions
} from 'react-native';
import BottomMenu from '../components/BottomMenu';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as SecureStore from 'expo-secure-store';
import Toast from 'react-native-toast-message';
import { BASE_URL } from '../config';

const { height } = Dimensions.get('window');

export default function ProfileScreen({ setIsLoggedIn }) {
  const [user, setUser] = useState(null);
  const [phone, setPhone] = useState('');
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(true);

  const handleLogout = async () => {
    await SecureStore.deleteItemAsync('token');
    setIsLoggedIn(false);
  };

  const fetchUser = async () => {
    try {
      const token = await SecureStore.getItemAsync('token');
      const response = await fetch(`${BASE_URL}/users/me`, {
        method: 'GET',
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!response.ok) throw new Error('Chyba pri načítaní profilu');

      const data = await response.json();
      setUser(data);
      setPhone(data.phone);
    } catch (error) {
      console.error('Chyba:', error.message);
    } finally {
      setLoading(false);
    }
  };

  const updatePhone = async () => {
    try {
      const token = await SecureStore.getItemAsync('token');
      const response = await fetch(`${BASE_URL}/users/me`, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ phone }),
      });

      const result = await response.json();
      if (response.ok) {
        Toast.show({ type: 'success', text1: result.message });
        setEditing(false);
        fetchUser(); // refresh
      } else {
        Toast.show({ type: 'error', text1: result.detail || 'Chyba pri aktualizácii' });
      }
    } catch (error) {
      console.error('Chyba:', error.message);
      Toast.show({ type: 'error', text1: 'Neočakávaná chyba' });
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
      <View style={styles.container}>
        <Text style={styles.title}>Profil</Text>
        <View style={styles.content}>
          {loading ? (
            <ActivityIndicator size="large" />
          ) : user ? (
            <>
              <Text style={styles.label}>Meno: <Text style={styles.value}>{user.first_name}</Text></Text>
              <Text style={styles.label}>Priezvisko: <Text style={styles.value}>{user.last_name}</Text></Text>
              <Text style={styles.label}>Vek: <Text style={styles.value}>{user.age}</Text></Text>
              <Text style={styles.label}>Škola: <Text style={styles.value}>{user.school}</Text></Text>
              <Text style={styles.label}>Email: <Text style={styles.value}>{user.email}</Text></Text>

              <View style={styles.phoneRow}>
                <Text style={styles.label}>Telefón:</Text>
                {editing ? (
                  <>
                    <TextInput
                      style={styles.input}
                      value={phone}
                      onChangeText={setPhone}
                      keyboardType="phone-pad"
                      placeholder="Nové číslo"
                    />
                    <TouchableOpacity onPress={updatePhone}>
                      <Text style={styles.saveLink}>Uložiť</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => setEditing(false)}>
                      <Text style={styles.cancelLink}>Zrušiť</Text>
                    </TouchableOpacity>
                  </>
                ) : (
                  <>
                    <Text style={styles.value}>{user.phone}</Text>
                    <TouchableOpacity onPress={() => setEditing(true)}>
                      <Text style={styles.editLink}>Upraviť</Text>
                    </TouchableOpacity>
                  </>
                )}
              </View>
            </>
          ) : (
            <Text style={{ marginTop: 20 }}>Nepodarilo sa načítať údaje.</Text>
          )}
        </View>

        <View style={styles.logoutContainer}>
          <Button title="Odhlásiť sa" onPress={handleLogout} />
        </View>

        <BottomMenu />
        <Toast />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 10,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    marginTop: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 12,
  },
  value: {
    fontWeight: 'normal',
  },
  phoneRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    marginTop: 12,
    gap: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 6,
    borderRadius: 6,
    width: 120,
  },
  editLink: {
    color: '#007AFF',
    textDecorationLine: 'underline',
    marginLeft: 10,
  },
  saveLink: {
    color: 'green',
    textDecorationLine: 'underline',
    marginLeft: 10,
  },
  cancelLink: {
    color: 'red',
    textDecorationLine: 'underline',
    marginLeft: 10,
  },
  logoutContainer: {
    position: 'absolute',
    top: height * 0.4, // cca 2/5 výšky obrazovky
    alignSelf: 'center',
  },
});
