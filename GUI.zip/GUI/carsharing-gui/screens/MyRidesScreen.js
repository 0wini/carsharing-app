import React, { useEffect, useState } from 'react';
import {
  View,
  ScrollView,
  Text,
  ActivityIndicator,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { useNavigation } from '@react-navigation/native';
import Toast from 'react-native-toast-message';
import MyRideInfo from '../components/MyRideInfo';
import BottomMenu from '../components/BottomMenu';
import { BASE_URL } from '../config';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function MyRidesScreen() {
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigation = useNavigation();

  useEffect(() => {
    const fetchRides = async () => {
      try {
        const token = await SecureStore.getItemAsync('token');
        const user_id = await AsyncStorage.getItem('user_id');

        if (!user_id || isNaN(parseInt(user_id))) {
          console.error("Neplatné alebo chýbajúce user_id:", user_id);
          Toast.show({
            type: 'error',
            text1: 'Chyba',
            text2: 'Nepodarilo sa načítať ID používateľa',
          });
          return;
        }

        const response = await fetch(`${BASE_URL}/rides/passenger/${user_id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await response.json();
        if (response.ok) {
          const sortedRides = data.sort((a, b) => {
            const statusOrder = (status) => (status === 'Rezervovaná' ? 0 : 1);
          
            const aStatus = statusOrder(a.status);
            const bStatus = statusOrder(b.status);
          
            if (aStatus !== bStatus) {
              return aStatus - bStatus;
            }
          
            const aDate = new Date(a.departure_time).getTime();
            const bDate = new Date(b.departure_time).getTime();
          
            // Rezervované: od najbližšej po najvzdialenejšiu
            if (a.status === 'Rezervovaná') {
              return aDate - bDate;
            }
          
            // Zrušené/Prebehnuté: od najnovšej po najstaršiu
            return bDate - aDate;
          });
          
          setRides(sortedRides);
        } else {
          console.error(data.detail);
          Toast.show({
            type: 'error',
            text1: 'Chyba',
            text2: data.detail || 'Nepodarilo sa načítať jazdy',
          });
        }
      } catch (err) {
        console.error('Chyba siete:', err);
        Toast.show({
          type: 'error',
          text1: 'Chyba siete',
          text2: 'Skontroluj pripojenie',
        });
      } finally {
        setLoading(false);
      }
    };

    fetchRides();
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />
        <Text>Načítava sa...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>
        {rides.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>Nemáš žiadne rezervované jazdy.</Text>
          </View>
        ) : (
          rides.map((ride, index) => (
            <TouchableOpacity
              key={index}
              onPress={() => navigation.navigate('MyRideInfoScreen', { ride })}
            >
              <MyRideInfo ride={ride} />
            </TouchableOpacity>
          ))
        )}
      </ScrollView>
      <BottomMenu />
    </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingBottom: 70,
  },
  scroll: {
    padding: 10,
    paddingBottom: 80,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 50,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
});
