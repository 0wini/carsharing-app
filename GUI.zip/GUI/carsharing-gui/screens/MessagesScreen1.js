import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import BottomMenu from '../components/BottomMenu';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function SearchRidesScreen() {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
      <View style={styles.container}>
        <View style={styles.content}>
          <Text>Správy</Text>
        </View>
        <BottomMenu />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
