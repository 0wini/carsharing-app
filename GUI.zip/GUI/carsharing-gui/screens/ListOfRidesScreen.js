import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Button, ActivityIndicator, StyleSheet, TouchableOpacity } from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import RideInfo from '../components/RideInfo';
import { BASE_URL } from "../config";
import { SafeAreaView } from 'react-native-safe-area-context';

export default function ListOfRidesScreen() {
  const route = useRoute();
  const navigation = useNavigation();
  const { origin, destination, date, seatsRequired } = route.params;

  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRides = async () => {
      try {
        const response = await fetch(
          `${BASE_URL}/rides/search?origin=${origin}&destination=${destination}&date_str=${date}&seats_required=${seatsRequired}`
        );
        const data = await response.json();
        if (response.ok) {
          const sortedRides = data.sort((a, b) => new Date(a.departure_time) - new Date(b.departure_time));
          setRides(sortedRides);
        } else {
          console.error('Chyba načítania jázd:', data.detail);
        }
      } catch (error) {
        console.error('Chyba siete:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchRides();
  }, [origin, destination, date]);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />
        <Text>Načítava sa...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
    <View style={styles.mainContainer}>
      <View style={styles.contentContainer}>
        <Text style={styles.dateText}>Dátum: {date}</Text>
        <ScrollView style={{ marginTop: 10 }}>
          {rides.length === 0 ? (
            <Text>Žiadne jazdy neboli nájdené.</Text>
          ) : (
            rides.map((ride, index) => (
              <TouchableOpacity
                key={index}
                onPress={() => {
                  console.log('Ride odoslaný do RideInfoScreen:', ride);
                  navigation.navigate('RideInfoScreen', { ride });
                }}
              >
                <RideInfo ride={ride} />
              </TouchableOpacity>
            ))
          )}
        </ScrollView>
      </View>

      <View style={styles.buttonContainer}>
        <Button title="Späť" onPress={() => navigation.goBack()} />
      </View>
    </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    justifyContent: 'space-between',
  },
  contentContainer: {
    flex: 1,
    padding: 10,
  },
  buttonContainer: {
    padding: 10,
    borderTopWidth: 1,
    borderColor: '#ccc',
    backgroundColor: '#f9f9f9',
    marginBottom: '5%', // posunie tlačidlo nahor o 10 % výšky obrazovky
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  dateText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

