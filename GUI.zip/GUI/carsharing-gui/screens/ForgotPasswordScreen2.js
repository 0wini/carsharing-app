import React from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function ForgotPasswordScreen2() {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 20, marginBottom: 20 }}>Zabudnuté heslo</Text>

      <TextInput
        placeholder="Nové heslo"
        secureTextEntry
        style={{ borderBottomWidth: 1, marginBottom: 10 }}
      />

      <TextInput
        placeholder="Zopakovať nové heslo"
        secureTextEntry
        style={{ borderBottomWidth: 1, marginBottom: 20 }}
      />

      <TouchableOpacity>
        <Text style={{ fontSize: 16, color: 'blue' }}>Zmeniť heslo</Text>
      </TouchableOpacity>
    </View>
    </SafeAreaView>
  );
}
