import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Keyboard,
  TouchableWithoutFeedback
} from 'react-native';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Toast from 'react-native-toast-message';
import { BASE_URL } from "../config";
import { SafeAreaView } from 'react-native-safe-area-context';

export default function LoginScreen({ navigation, onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    if (!email || !password) {
      Toast.show({
        type: 'error',
        text1: 'Chyba',
        text2: 'Zadaj e-mail a heslo'
      });
      return;
    }

    try {
      const response = await fetch(`${BASE_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (response.ok) {
        // 🔐 bezpečný token
        await SecureStore.setItemAsync("token", data.access_token);

        // 📦 bežné údaje (id, email)
        await AsyncStorage.setItem("user_id", String(data.user_id));
        await AsyncStorage.setItem("user_email", email);

        Toast.show({
          type: 'success',
          text1: 'Prihlásenie úspešné'
        });

        onLogin(); // prepnutie do hlavného menu
      } else {
        const errorText =
          typeof data.detail === 'string'
            ? data.detail
            : Array.isArray(data.detail)
              ? data.detail.map((e) => e.msg).join(', ')
              : 'Neznáme prihlasovacie údaje';

        Toast.show({
          type: 'error',
          text1: 'Chyba',
          text2: errorText,
        });
      }
    } catch (error) {
      Toast.show({
        type: 'error',
        text1: 'Chyba siete',
        text2: 'Nepodarilo sa pripojiť na server'
      });
      console.error(error);
    }
  };

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
      <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
        <View style={{ padding: 20 }}>
          <Text>Prihlás sa</Text>

          <TextInput
            placeholder="Email"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            style={{ borderBottomWidth: 1, marginBottom: 10 }}
          />

          <TextInput
            placeholder="Heslo"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            style={{ borderBottomWidth: 1, marginBottom: 20 }}
          />

          <TouchableOpacity onPress={handleLogin}>
            <Text>prihlásiť</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('RegisterScreen1')}>
            <Text style={{ color: 'blue', marginTop: 10 }}>Ešte nemám účet</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('ForgotPasswordScreen1')}>
            <Text style={{ color: 'blue', marginTop: 5 }}>Zabudol som heslo</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </TouchableWithoutFeedback>
  );
}
