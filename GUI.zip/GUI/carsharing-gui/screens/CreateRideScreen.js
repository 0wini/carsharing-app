import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Switch,
  Keyboard,
  StyleSheet,
  Platform,
  TouchableWithoutFeedback
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import * as SecureStore from 'expo-secure-store';
import Toast from 'react-native-toast-message';
import { SafeAreaView } from 'react-native-safe-area-context';
import municipalities from '../data/municipalities';
import { BASE_URL } from '../config';
import BottomMenu from '../components/BottomMenu';

export default function CreateRideScreen({ navigation }) {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [date, setDate] = useState(new Date());
  const [tempDate, setTempDate] = useState(new Date());
  const [showPicker, setShowPicker] = useState(false);
  const [seats, setSeats] = useState('');
  const [price, setPrice] = useState('');
  const [comment, setComment] = useState('');
  const [isRecurring, setIsRecurring] = useState(false);
  const [periodic, setPeriodic] = useState('');
  const [originSuggestions, setOriginSuggestions] = useState([]);
  const [destinationSuggestions, setDestinationSuggestions] = useState([]);

  const formatDate = (d) => d.toISOString().split('T')[0];
  const formatTime = (d) => d.toTimeString().slice(0, 5);

  const filterSuggestions = (text, setInput, setSuggestions) => {
    setInput(text);
    if (text.length === 0) {
      setSuggestions([]);
    } else {
      const matches = municipalities.filter((item) =>
        item.toLowerCase().startsWith(text.toLowerCase())
      );
      setSuggestions(matches);
    }
  };

  const handleCreateRide = async () => {
    if (!origin || !destination || !seats || !price) {
      Toast.show({
        type: 'error',
        text1: 'Chýbajúce údaje',
        text2: 'Vyplň začiatok, cieľ, počet miest a cenu.',
      });
      return;
    }

    try {
      const token = await SecureStore.getItemAsync('token');

      const rideData = {
        origin,
        destination,
        departure_time: date.toISOString(),
        seats_available: parseInt(seats),
        price: parseFloat(price),
        comment,
        is_recurring: isRecurring,
        periodic,
      };

      const response = await fetch(`${BASE_URL}/rides`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(rideData),
      });

      if (response.ok) {
        Toast.show({ type: 'success', text1: 'Jazda vytvorená' });
        navigation.navigate('MyRides');
      } else {
        const text = await response.text();
        Toast.show({ type: 'error', text1: 'Chyba', text2: text });
      }
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Chyba siete' });
    }
  };

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
      <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
        <View style={{ flex: 1, padding: 20 }}>
          <Text style={styles.label}>Začiatok cesty</Text>
          <TextInput
            value={origin}
            onChangeText={(text) => filterSuggestions(text, setOrigin, setOriginSuggestions)}
            style={styles.input}
          />
          {originSuggestions.length > 0 && (
            <View>
              {originSuggestions.map((item) => (
                <TouchableOpacity key={item} onPress={() => {
                  setOrigin(item);
                  setOriginSuggestions([]);
                  Keyboard.dismiss();
                }}>
                  <Text style={styles.suggestionItem}>{item}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          <Text style={styles.label}>Cieľ cesty</Text>
          <TextInput
            value={destination}
            onChangeText={(text) => filterSuggestions(text, setDestination, setDestinationSuggestions)}
            style={styles.input}
          />
          {destinationSuggestions.length > 0 && (
            <View>
              {destinationSuggestions.map((item) => (
                <TouchableOpacity
                  key={item}
                  onPress={() => {
                    setDestination(item);
                    setDestinationSuggestions([]);
                    Keyboard.dismiss();
                  }}
                >
                  <Text style={styles.suggestionItem}>{item}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          <TouchableOpacity onPress={() => setShowPicker(true)}>
            <Text style={styles.input}>
              {date.toLocaleDateString('sk-SK')} {formatTime(date)}
            </Text>
          </TouchableOpacity>

          {showPicker && (
            <View style={{ backgroundColor: 'white', padding: 10 }}>
              <DateTimePicker
                value={tempDate}
                mode="datetime"
                display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                onChange={(event, selectedDate) => {
                  if (selectedDate) setTempDate(selectedDate);
                }}
              />
              <TouchableOpacity onPress={() => {
                setDate(tempDate);
                setShowPicker(false);
              }}>
                <Text style={{ color: 'blue', textAlign: 'right', paddingTop: 10 }}>Hotovo</Text>
              </TouchableOpacity>
            </View>
          )}

          <TextInput
            placeholder="Počet miest"
            keyboardType="numeric"
            value={seats}
            onChangeText={setSeats}
            style={styles.input}
          />

          <TextInput
            placeholder="Cena (€)"
            keyboardType="numeric"
            value={price}
            onChangeText={setPrice}
            style={styles.input}
          />

          <TextInput
            placeholder="Poznámka"
            value={comment}
            onChangeText={setComment}
            style={styles.input}
          />

          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
            <Text style={{ marginRight: 10 }}>Opakovaná jazda?</Text>
            <Switch value={isRecurring} onValueChange={setIsRecurring} />
          </View>

          {isRecurring && (
            <TextInput
              placeholder="Periodickosť (napr. každý piatok)"
              value={periodic}
              onChangeText={setPeriodic}
              style={styles.input}
            />
          )}

          <TouchableOpacity onPress={handleCreateRide} style={{ marginTop: 20 }}>
            <Text style={{ fontSize: 16, color: 'blue' }}>Vytvoriť jazdu</Text>
          </TouchableOpacity>

          <View style={styles.bottomMenu}>
            <BottomMenu navigation={navigation} />
          </View>
        </View>
      </SafeAreaView>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  input: {
    borderBottomWidth: 1,
    marginBottom: 15,
    paddingVertical: 5,
    color: 'black',
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  suggestionItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderColor: '#eee',
  },
  bottomMenu: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 10,
    backgroundColor: 'white',
  }
});
