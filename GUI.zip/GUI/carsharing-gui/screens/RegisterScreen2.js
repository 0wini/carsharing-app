import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Platform,
  Keyboard,
  TouchableWithoutFeedback,
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import Toast from 'react-native-toast-message';
import { BASE_URL } from "../config";
import { SafeAreaView } from 'react-native-safe-area-context';


export default function RegisterScreen2({ route, navigation }) {
  const { email, password } = route.params;
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [birthDate, setBirthDate] = useState(new Date());
  const [phone, setPhone] = useState('');
  const [showPicker, setShowPicker] = useState(false);

  const onChange = (event, selectedDate) => {
    if (selectedDate) setBirthDate(selectedDate);
  };
  

  const handleRegister = async () => {
    try {
      const response = await fetch(`${BASE_URL}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          password,
          first_name: firstName,
          last_name: lastName,
          birth_date: birthDate.toISOString().split('T')[0],
          phone,
        }),
      });

      if (response.ok) {
        Toast.show({
          type: 'success',
          text1: 'Registrácia úspešná',
        });
        navigation.navigate('LoginScreen');
      } else {
        const data = await response.json();
        Toast.show({
          type: 'error',
          text1: 'Chyba pri registrácii',
          text2: data.detail || 'Neznáma chyba',
        });
      }
    } catch (error) {
      Toast.show({
        type: 'error',
        text1: 'Chyba',
        text2: 'Nepodarilo sa pripojiť na server',
      });
      console.error(error);
    }
  };

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
      <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
        <View style={{ padding: 20 }}>
          <Text style={{ fontSize: 20, marginBottom: 20 }}>Zaregistruj sa</Text>

          <TextInput
            placeholder="Meno"
            value={firstName}
            onChangeText={setFirstName}
            style={{ borderBottomWidth: 1, marginBottom: 10 }}
          />

          <TextInput
            placeholder="Priezvisko"
            value={lastName}
            onChangeText={setLastName}
            style={{ borderBottomWidth: 1, marginBottom: 10 }}
          />

          <TouchableOpacity onPress={() => setShowPicker(true)}>
            <Text style={{ borderBottomWidth: 1, marginBottom: 10, paddingVertical: 8 }}>
              {birthDate.toLocaleDateString('sk-SK')}
            </Text>
          </TouchableOpacity>

          {showPicker && Platform.OS === 'ios' && (
            <View style={{ backgroundColor: 'white', padding: 10 }}>
              <DateTimePicker
                value={birthDate}
                mode="date"
                display="spinner"
                onChange={onChange}
                maximumDate={new Date(2100, 11, 31)}
              />
              <TouchableOpacity onPress={() => setShowPicker(false)}>
                <Text style={{ color: 'blue', textAlign: 'right', paddingTop: 10 }}>Hotovo</Text>
              </TouchableOpacity>
            </View>
          )}


          {showPicker && Platform.OS === 'android' && (
            <DateTimePicker
              value={birthDate}
              mode="date"
              display="default"
              onChange={(event, selectedDate) => {
                setShowPicker(false);
                if (selectedDate) setBirthDate(selectedDate);
              }}
              maximumDate={new Date(2100, 11, 31)}
            />
          )}




          <TextInput
            placeholder="Tel. číslo"
            value={phone}
            onChangeText={setPhone}
            keyboardType="phone-pad"
            style={{ borderBottomWidth: 1, marginBottom: 20 }}
          />

          <TouchableOpacity onPress={handleRegister}>
            <Text style={{ fontSize: 16, color: 'blue' }}>Registrovať</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </TouchableWithoutFeedback>
  );
}
