import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Keyboard, TouchableWithoutFeedback } from 'react-native';
import Toast from 'react-native-toast-message';
import { allowedDomains } from '../config';
import { BASE_URL } from "../config";
import { SafeAreaView } from 'react-native-safe-area-context';

export default function RegisterScreen1({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const validatePassword = (pw) => {
    const hasNumber = /\d/;
    return pw.length >= 7 && hasNumber.test(pw);
  };

  const handleNext = async () => {
    const domain = email.split('@')[1];

    if (!allowedDomains.includes(domain)) {
      Toast.show({
        type: 'error',
        text1: 'Neplatná doména',
        text2: 'Zadaj školský e-mail (napr. stuba.sk)',
      });
      return;
    }

    if (!validatePassword(password)) {
      Toast.show({
        type: 'error',
        text1: 'Slabé heslo',
        text2: 'Heslo musí mať aspoň 7 znakov a obsahovať aspoň jedno číslo.',
      });
      return;
    }

    if (password !== confirmPassword) {
      Toast.show({
        type: 'error',
        text1: 'Chyba',
        text2: 'Heslá sa nezhodujú',
      });
      return;
    }

    try {
      const response = await fetch(`${BASE_URL}/check-email?email=${encodeURIComponent(email)}`, {
        method: 'GET'
      });

      if (!response.ok) {
        Toast.show({
          type: 'error',
          text1: 'Chyba',
          text2: 'Nepodarilo sa overiť e-mail',
        });
        return;
      }

      const data = await response.json();
      if (data.exists) {
        Toast.show({
          type: 'error',
          text1: 'Tento e-mail sa už používa',
        });
        return;
      }

      // E-mail je voľný → pokračuj
      navigation.navigate('RegisterScreen2', { email, password });

    } catch (error) {
      Toast.show({
        type: 'error',
        text1: 'Chyba pripojenia',
        text2: 'Skontroluj sieťové pripojenie',
      });
      console.error(error);
    }
  };

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
      <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
        <View style={{ padding: 20 }}>
          <Text style={{ fontSize: 20, marginBottom: 20 }}>Zaregistruj sa</Text>

          <TextInput
            placeholder="Email"
            style={{ borderBottomWidth: 1, marginBottom: 10 }}
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
          />

          <TextInput
            placeholder="Heslo"
            secureTextEntry
            style={{ borderBottomWidth: 1, marginBottom: 10 }}
            value={password}
            onChangeText={setPassword}
          />

          <TextInput
            placeholder="Potvrď heslo"
            secureTextEntry
            style={{ borderBottomWidth: 1, marginBottom: 20 }}
            value={confirmPassword}
            onChangeText={setConfirmPassword}
          />

          <TouchableOpacity onPress={handleNext}>
            <Text style={{ fontSize: 16, color: 'blue' }}>Pokračovať</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('LoginScreen')}>
            <Text style={{ color: 'blue', marginTop: 10 }}>Už mám účet</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </TouchableWithoutFeedback>
  );
}
