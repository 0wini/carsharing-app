import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Keyboard,
  Platform,
  TouchableWithoutFeedback
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import BottomMenu from '../components/BottomMenu';
import municipalities from '../data/municipalities';
import { SafeAreaView } from 'react-native-safe-area-context';
import Toast from 'react-native-toast-message';


export default function SearchRideScreen({ navigation }) {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [date, setDate] = useState(new Date());
  const [showPicker, setShowPicker] = useState(false);
  const [originSuggestions, setOriginSuggestions] = useState([]);
  const [destinationSuggestions, setDestinationSuggestions] = useState([]);
  const [seatsRequired, setSeatsRequired] = useState(1);

  const onChange = (event, selectedDate) => {
    if (selectedDate) setDate(selectedDate);
  };
  

  const handleSearch = () => {
    if (!origin || !destination) {
      Toast.show({
        type: 'error',
        text1: 'Chýbajúce údaje',
        text2: 'Vyplň začiatok a cieľ cesty.',
      });
      return;
    }
  
    navigation.navigate('ListOfRides', {
      origin,
      destination,
      date: `${date.getFullYear()}-${(date.getMonth()+1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}`,
      seatsRequired,
    });
  };

  const filterSuggestions = (text, setInput, setSuggestions) => {
    setInput(text);
    if (text.length === 0) {
      setSuggestions([]);
    } else {
      const matches = municipalities.filter((item) =>
        item.toLowerCase().startsWith(text.toLowerCase())
      );
      setSuggestions(matches);
    }
  };

  const formatDate = (date) => date.toLocaleDateString('sk-SK');

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
      <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
        <View style={styles.mainContainer}>
          <View style={styles.container}>
            <View style={{ position: 'relative' }}>
              <TextInput
                placeholder="Začiatok z"
                value={origin}
                onChangeText={(text) =>
                  filterSuggestions(text, setOrigin, setOriginSuggestions)
                }
                style={styles.input}
              />
              {originSuggestions.length > 0 && (
                <View style={styles.suggestions}>
                  <FlatList
                    data={originSuggestions}
                    keyExtractor={(item) => item}
                    renderItem={({ item }) => (
                      <TouchableOpacity
                        onPress={() => {
                          setOrigin(item);
                          setOriginSuggestions([]);
                          Keyboard.dismiss();
                        }}
                      >
                        <Text style={styles.suggestionItem}>{item}</Text>
                      </TouchableOpacity>
                    )}
                  />
                </View>
              )}
            </View>

            <View style={{ position: 'relative' }}>
              <TextInput
                placeholder="Cieľ do"
                value={destination}
                onChangeText={(text) =>
                  filterSuggestions(text, setDestination, setDestinationSuggestions)
                }
                style={styles.input}
              />
              {destinationSuggestions.length > 0 && (
                <View style={styles.suggestions}>
                  <FlatList
                    data={destinationSuggestions}
                    keyExtractor={(item) => item}
                    renderItem={({ item }) => (
                      <TouchableOpacity
                        onPress={() => {
                          setDestination(item);
                          setDestinationSuggestions([]);
                          Keyboard.dismiss();
                        }}
                      >
                        <Text style={styles.suggestionItem}>{item}</Text>
                      </TouchableOpacity>
                    )}
                  />
                </View>
              )}
            </View>

            <View style={styles.row}>
              <TouchableOpacity
                onPress={() => setShowPicker(true)}
                style={[styles.input, styles.dateInput]}
              >
                <Text style={styles.dateText}>{formatDate(date)}</Text>
              </TouchableOpacity>

              <TextInput
                placeholder="Osoby"
                value={seatsRequired.toString()}
                onChangeText={(text) => setSeatsRequired(Number(text))}
                keyboardType="numeric"
                style={[styles.input, styles.timeInput]}
              />
            </View>

            {showPicker && Platform.OS === 'ios' && (
              <View style={{ backgroundColor: 'white', padding: 10 }}>
                <DateTimePicker
                  value={date}
                  mode="date"
                  display="spinner"
                  onChange={onChange}
                  maximumDate={new Date(2100, 11, 31)}
                />
                <TouchableOpacity onPress={() => setShowPicker(false)}>
                  <Text style={{ color: 'blue', textAlign: 'right', paddingTop: 10 }}>Hotovo</Text>
                </TouchableOpacity>
              </View>
            )}

            {showPicker && Platform.OS === 'android' && (
              <DateTimePicker
                value={date}
                mode="date"
                display="default"
                onChange={(event, selectedDate) => {
                  setShowPicker(false);
                  if (selectedDate) setDate(selectedDate);
                }}
                maximumDate={new Date(2100, 11, 31)}
              />
            )}


            <Button title="Hľadať" onPress={handleSearch} />
          </View>

          <BottomMenu />
        </View>
      </SafeAreaView>
    </TouchableWithoutFeedback>  
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    padding: 20,
  },
  input: {
    borderBottomWidth: 1,
    marginBottom: 15,
    paddingVertical: 5,
    zIndex: 1,
  },
  dateInput: {
    flex: 1,
  },
  timeInput: {
    flex: 1,
    marginLeft: 10,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  dateText: {
    fontSize: 16,
  },
  suggestions: {
    position: 'absolute',
    top: 45,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    zIndex: 999,
    elevation: 3,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  suggestionItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderColor: '#eee',
  },
});
