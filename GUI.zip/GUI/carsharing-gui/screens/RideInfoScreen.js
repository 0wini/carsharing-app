import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Button, ScrollView } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import Toast from 'react-native-toast-message';
import { BASE_URL } from "../config";
import { SafeAreaView } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function RideInfoScreen({ route, navigation }) {
  const { ride } = route.params;
  const [rideDetails, setRideDetails] = useState(null);
  const [currentUserId, setCurrentUserId] = useState(null);
  const [currentUserEmail, setCurrentUserEmail] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const storedEmail = await AsyncStorage.getItem('user_email');
        setCurrentUserEmail(storedEmail);
      } catch (error) {
        console.error('Chyba pri načítaní emailu:', error);
      }
  
      fetchRideDetail();
    };
  
    fetchData();
  }, [ride.id]);

  const fetchRideDetail = async () => {
    try {
      const storedId = await SecureStore.getItemAsync("user_id");
      setCurrentUserId(Number(storedId));
  
      const res = await fetch(`${BASE_URL}/rides/${ride.id}`);
      if (!res.ok) {
        throw new Error(`Chyba ${res.status}`);
      }
      const data = await res.json();
      setRideDetails(data);
    } catch (error) {
      console.error("Chyba pri načítaní údajov:", error);
    }
  };
  

  const formatDateTime = (isoString) => {
    const date = new Date(isoString);
    return `${date.getDate()}. ${date.getMonth() + 1}. ${date.getFullYear()}, ${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}`;
  };

  const joinRide = async () => {
    try {
      const token = await SecureStore.getItemAsync("token");
      const res = await fetch(`${BASE_URL}/rides/${ride.id}/join`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!res.ok) {
        const errRes = await res.json();
        Toast.show({ type: 'error', text1: errRes.detail || "Chyba pri rezervácii." });
        return;
      }

      const result = await res.json();
      Toast.show({ type: 'success', text1: result.message });
      fetchRideDetail();  // Refresh po rezervácii
    } catch (err) {
      Toast.show({ type: 'error', text1: "Chyba pri rezervácii." });
    }
  };

  if (!rideDetails) return <Text>Načítava sa...</Text>;

  const { ride: rideInfo, driver, passengers } = rideDetails;
  const driverFullName = `${driver.first_name} ${driver.last_name?.charAt(0)}.`;

  const isDriver = driver.email === currentUserEmail;
  const isAlreadyPassenger = passengers.some((p) => p.id === currentUserId);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Informácie o jazde</Text>

      <Text style={styles.label}>Vodič:</Text>
      <Text style={styles.value}>{driverFullName}</Text>

      <Text style={styles.label}>Trasa:</Text>
      <Text style={styles.value}>{rideInfo.origin} ➞ {rideInfo.destination}</Text>

      <Text style={styles.label}>Odchod:</Text>
      <Text style={styles.value}>{formatDateTime(rideInfo.departure_time)}</Text>

      <Text style={styles.label}>Cena:</Text>
      <Text style={styles.value}>{rideInfo.price} €</Text>

      <Text style={styles.label}>Voľné miesta:</Text>
      <Text style={styles.value}>{rideInfo.seats_available}</Text>

      <Text style={styles.label}>Opakovanie:</Text>
      <Text style={styles.value}>{rideInfo.is_recurring ? "Áno" : "Nie"}</Text>

      {rideInfo.periodic && (
        <>
          <Text style={styles.label}>Dni opakovania:</Text>
          <Text style={styles.value}>{rideInfo.periodic}</Text>
        </>
      )}

      {rideInfo.comment && (
        <>
          <Text style={styles.label}>Poznámka:</Text>
          <Text style={styles.value}>{rideInfo.comment}</Text>
        </>
      )}

      <Text style={styles.label}>Cestujúci:</Text>
      {Array.isArray(passengers) && passengers.length > 0 ? (
        passengers.map((p, index) => (
          <Text key={index} style={styles.value}>
            {p.first_name} {p.last_name?.charAt(0)}.
          </Text>
        ))
        
      ) : (
        <Text style={styles.value}>Zatiaľ žiadni</Text>
      )}

      {!isDriver && !isAlreadyPassenger && (
        <View style={styles.buttonContainer}>
          <Button title="Zarezervovať miesto" onPress={joinRide} />
        </View>
      )}

      <View style={styles.buttonContainer}>
        <Button title="Späť" onPress={() => navigation.goBack()} />
      </View>
      <Toast />
    </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  label: { fontSize: 16, fontWeight: 'bold', marginTop: 10 },
  value: { fontSize: 16, marginBottom: 5 },
  buttonContainer: { marginTop: 20 },
});
